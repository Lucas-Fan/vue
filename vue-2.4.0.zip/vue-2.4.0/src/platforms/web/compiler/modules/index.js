import klass from './class'
import style from './style'

export default [
  klass,
  style
]
